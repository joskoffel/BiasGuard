/**
 * Content script for BiasGuard. This script could analyse the current
 * document and extract the main article text or metadata for the bias
 * inference. In this scaffold it does nothing by default. You may
 * communicate with the background script using chrome.runtime.sendMessage.
 */
// Placeholder content script – no-op. To implement site integration
// logic, add code here to extract page content and send it to the
// background script via messages.