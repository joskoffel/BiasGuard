/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable strict mode for catching common bugs
  reactStrictMode: true,
  // Allow importing SVGs as React components
  webpack(config) {
    config.module.rules.push({
      test: /\.svg$/,
      use: ['@svgr/webpack'],
    });
    return config;
  },
};

module.exports = nextConfig;